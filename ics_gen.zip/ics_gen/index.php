<?php
error_reporting(E_ALL);
ini_set('display_errors', '0');

/**
 * Event information 
 */
//$event = get_event($event_id);
$event = array(
    'event_name' => 'Harman Event',
    'event_description' => 'This is a Harman event. This is the description.',
    'event_start' => strtotime("14-03-2023 10:00"),
    'event_end' => strtotime("14-03-2023 10:30"),
    'event_venue' => array(
        'venue_name' => 'Test Venue',
        'venue_address' => '123 Test Drive',
        'venue_address_two' => 'Suite 555',
        'venue_city' => 'Some City',
        'venue_state' => 'Iowa',
        'venue_postal_code' => '12345'
    )
);
$name = $event['event_name'];
$venue = $event['event_venue'];
$location = $venue['venue_name'] . ', ' . $venue['venue_address'] . ', ' . $venue['venue_address_two'] . ', ' . $venue['venue_city'] . ', ' . $venue['venue_state'] . ' ' . $venue['venue_postal_code']; 



echo $event['event_start'] ."=======";
echo $event['event_end'];
echo "<br>";

echo $start = date('Ymd', strtotime('+4 hour +30 minutes',($event['event_start']))) . 'T' . date('His',strtotime('+4 hour +30 minutes',($event['event_start']))) . 'Z';
echo "<br>=========";
echo $end = date('Ymd', strtotime('+4 hour +30 minutes',($event['event_end']))) . 'T' . date('His',strtotime('+4 hour +30 minutes',($event['event_end']))). 'Z';

//die;

$description = $event['event_description'];
$slug = strtolower(str_replace(array(' ', "'", '.'), array('_', '', ''), $name));
header("Content-Type: text/Calendar; charset=utf-8");
header("Content-Disposition: inline; filename=Googlemeet.ics");

echo "BEGIN:VCALENDAR\n";
echo "VERSION:2.0\n";
echo "PRODID:-//LearnPHP.co//NONSGML {$name}//EN\n";
echo "METHOD:REQUEST\n"; // requied by Outlook
echo "BEGIN:VEVENT\n";
echo "UID: 589655\n"; // required by Outlok
echo "DTSTAMP:".date('Ymd').'T'.date('his')."Z\n"; // required by Outlook
echo "DTSTART:{$start}\n"; 
echo "DTEND:{$end}\n";
echo "LOCATION:{$location}\n";
echo "SUMMARY:{$name}\n";
echo "DESCRIPTION: {$description}\n";
echo "END:VEVENT\n";
echo "END:VCALENDAR\n";


?>