<?php

header("Content-Type: text/Calendar; charset=utf-8");
header("Content-Disposition: inline; filename=Googlemeet.ics");

// DTSTART should be meeeting start time
// DTEND should be meeeting End time

echo "BEGIN:VCALENDAR
VERSION:2.0
PRODID:-//ical.marudot.com//iCal Event Maker
CALSCALE:GREGORIAN
BEGIN:VTIMEZONE
TZID:Asia/Kolkata
LAST-MODIFIED:20201011T015911Z
TZURL:http://tzurl.org/zoneinfo-outlook/Asia/Kolkata
X-LIC-LOCATION:Asia/Kolkata
BEGIN:STANDARD
TZNAME:IST
TZOFFSETFROM:+0530
TZOFFSETTO:+0530
END:STANDARD
END:VTIMEZONE
BEGIN:VEVENT
DTSTAMP:20230313T100000Z
UID:1678701111161-24363@ical.marudot.com
DTSTART;TZID=Asia/Calcutta:20230324T102000
DTEND;TZID=Asia/Calcutta:20230324T104000
SUMMARY:Testing demo
END:VEVENT
END:VCALENDAR";


?>